import sys

def sort_check(filename):
    with open(filename, 'r') as file:
        _ = int(file.readline())  # Skip the first line
        prev_num = float('-inf')  # Initialize prev_num to negative infinity
        for line in file:
            nums = map(int, line.split())  # Split the line into separate integers
            for num in nums:
                if num < prev_num:
                    return False
                prev_num = num
    return True

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script_name.py filename")
        sys.exit(1)
    
    filename = sys.argv[1]
    print(sort_check(filename))
