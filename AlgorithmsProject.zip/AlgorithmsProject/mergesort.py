import sys

def merge_sort(filename):
    # Function for merging two sorted arrays
    def merge(left, right):
        merged = []
        i = j = inversions = 0
        while i < len(left) and j < len(right):
            if left[i] <= right[j]:
                merged.append(left[i])
                i += 1
            else:
                merged.append(right[j])
                j += 1
                inversions += len(left) - i
        merged.extend(left[i:])
        merged.extend(right[j:])
        return merged, inversions
    
    # Function for sorting using merge sort
    def sort(arr):
        if len(arr) <= 1:
            return arr, 0
        mid = len(arr) // 2
        left, inversions_left = sort(arr[:mid])
        right, inversions_right = sort(arr[mid:])
        merged, inversions_merge = merge(left, right)
        return merged, inversions_left + inversions_right + inversions_merge
    
    # Read the input array from file
    with open(filename, 'r') as file:
        _ = int(file.readline())  
        arr = list(map(int, file.readline().split()))
    
    # Perform merge sort and count comparisons
    sorted_arr, comparisons = sort(arr)
    return sorted_arr, comparisons

if __name__ == "__main__":
    # Check if the correct number of arguments is provided
    if len(sys.argv) != 2:
        print("Usage: python script_name.py filename")
        sys.exit(1)

    # Get the filename from command line arguments
    filename = sys.argv[1]
    
    # Perform merge sort and print the results
    sorted_arr, comparisons = merge_sort(filename)
    print("Sorted array:", sorted_arr)
    print("Total comparisons:", comparisons)
