import sys

def insertion_sort(arr):
    # Function for insertion sort
    comparisons = 0
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
            comparisons += 1
        arr[j + 1] = key
    return comparisons

def ins_mergesort(arr, M):
    # Function for insertion merge sort
    comparisons = 0
    if len(arr) > M:
        mid = len(arr) // 2
        left = arr[:mid]
        right = arr[mid:]
        comparisons += ins_mergesort(left, M)
        comparisons += ins_mergesort(right, M)
        i = j = k = 0
        while i < len(left) and j < len(right):
            if left[i] <= right[j]:
                arr[k] = left[i]
                i += 1
            else:
                arr[k] = right[j]
                j += 1
                comparisons += len(left) - i
            k += 1
        while i < len(left):
            arr[k] = left[i]
            i += 1
            k += 1
        while j < len(right):
            arr[k] = right[j]
            j += 1
            k += 1
    else:
        comparisons += insertion_sort(arr)
    return comparisons

def ins_mergesort_from_file(filename):
    # Function to read from file and perform insertion merge sort
    with open(filename, 'r') as file:
        _ = int(file.readline())  # Ignore the first line
        arr = list(map(int, file.readline().split()))
    comparisons = ins_mergesort(arr, len(arr) // 2)  # M value is half of the total number of elements
    return comparisons, arr

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script_name.py filename")
        sys.exit(1)

    filename = sys.argv[1]
    comparisons, sorted_arr = ins_mergesort_from_file(filename)
    print("Sorted array:", sorted_arr)
    print("Total comparisons:", comparisons)
