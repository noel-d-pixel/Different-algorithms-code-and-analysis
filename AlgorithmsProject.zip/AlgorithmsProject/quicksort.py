import sys
import random

def partition(arr, low, high):
    # Choose the pivot value randomly
    pivot_index = random.randint(low, high)
    arr[pivot_index], arr[high] = arr[high], arr[pivot_index]
    pivot = arr[high]
    
    i = low - 1
    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1

def quicksort(arr, low, high):
    # Quicksort function
    comparisons = 0
    if low < high:
        pi = partition(arr, low, high)
        comparisons += high - low
        comparisons += quicksort(arr, low, pi - 1)
        comparisons += quicksort(arr, pi + 1, high)
    return comparisons  

def quicksort_from_file(filename):
    # Function to perform quicksort on an array from a file
    with open(filename, 'r') as file:
        _ = int(file.readline())  
        arr = list(map(int, file.readline().split()))
    comparisons = quicksort(arr, 0, len(arr) - 1)
    return arr, comparisons

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script_name.py filename")
        sys.exit(1)

    filename = sys.argv[1]
    sorted_arr, comparisons = quicksort_from_file(filename)
    print("Sorted array:", sorted_arr)
    print("Total comparisons:", comparisons)
