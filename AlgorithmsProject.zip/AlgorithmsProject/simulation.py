import random

# Secure random number generator
def generate_random_array(size):
    return [random.randint(0, 1000) for _ in range(size)]

# Insertion sort algorithm
def custom_insertion_sort(arr):
    comparisons = 0
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
            comparisons += 1
        arr[j + 1] = key
    return comparisons

# Merge sort algorithm
def custom_merge_sort(arr):
    comparisons = 0
    if len(arr) > 1:
        mid = len(arr) // 2
        left_half = arr[:mid]
        right_half = arr[mid:]

        comparisons += custom_merge_sort(left_half)
        comparisons += custom_merge_sort(right_half)

        i = j = k = 0
        while i < len(left_half) and j < len(right_half):
            if left_half[i] <= right_half[j]:
                arr[k] = left_half[i]
                i += 1
            else:
                arr[k] = right_half[j]
                j += 1
                comparisons += len(left_half) - i
            k += 1

        while i < len(left_half):
            arr[k] = left_half[i]
            i += 1
            k += 1

        while j < len(right_half):
            arr[k] = right_half[j]
            j += 1
            k += 1
    return comparisons

# Quick sort algorithm
def custom_quick_sort(arr, low, high):
    comparisons = 0
    if low < high:
        pi, comps = custom_partition(arr, low, high)
        comparisons += comps
        comparisons += custom_quick_sort(arr, low, pi - 1)
        comparisons += custom_quick_sort(arr, pi + 1, high)
    return comparisons

def custom_partition(arr, low, high):
    pivot = arr[high]
    i = low - 1
    for j in range(low, high):
        if arr[j] < pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1, high - low

# Heapify function for heapsort
def custom_heapify(arr, n, i):
    largest = i
    l = 2 * i + 1
    r = 2 * i + 2
    
    if l < n and arr[l] > arr[largest]:
        largest = l
    
    if r < n and arr[r] > arr[largest]:
        largest = r
    
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        custom_heapify(arr, n, largest)

# Heapsort algorithm
def custom_heap_sort(arr):
    n = len(arr)

    # Build a max heap.
    for i in range(n // 2 - 1, -1, -1):
        custom_heapify(arr, n, i)
    
    comparisons = 0

    # One by one extract elements
    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]
        comparisons += 1
        custom_heapify(arr, i, 0)
    
    return comparisons

# Insertion-Merge sort algorithm
def ins_mergesort(arr, M):
    comparisons = 0
    if len(arr) > M:
        mid = len(arr) // 2
        left = arr[:mid]
        right = arr[mid:]
        comparisons += ins_mergesort(left, M)
        comparisons += ins_mergesort(right, M)
        i = j = k = 0
        while i < len(left) and j < len(right):
            if left[i] <= right[j]:
                arr[k] = left[i]
                i += 1
            else:
                arr[k] = right[j]
                j += 1
                comparisons += len(left) - i
            k += 1
        while i < len(left):
            arr[k] = left[i]
            i += 1
            k += 1
        while j < len(right):
            arr[k] = right[j]
            j += 1
            k += 1
    else:
        comparisons += custom_insertion_sort(arr)
    return comparisons

if __name__ == "__main__":
    # Define the input sizes
    sizes = list(range(0, 1001, 100))

    # Define the number of random arrays per input size
    num_arrays = 5

    # Print the results
    print("Comparisons for Custom Insertion Sort:")
    for size in sizes:
        total_comparisons = 0
        for _ in range(num_arrays):
            random_array = generate_random_array(size)
            comparisons = custom_insertion_sort(random_array)
            total_comparisons += comparisons
        print(f"Input Size: {size}, Total Comparisons: {total_comparisons}")

    print("\nComparisons for Custom Merge Sort:")
    for size in sizes:
        total_comparisons = 0
        for _ in range(num_arrays):
            random_array = generate_random_array(size)
            comparisons = custom_merge_sort(random_array)
            total_comparisons += comparisons
        print(f"Input Size: {size}, Total Comparisons: {total_comparisons}")

    print("\nComparisons for Custom Quick Sort:")
    for size in sizes:
        total_comparisons = 0
        for _ in range(num_arrays):
            random_array = generate_random_array(size)
            comparisons = custom_quick_sort(random_array, 0, len(random_array) - 1)
            total_comparisons += comparisons
        print(f"Input Size: {size}, Total Comparisons: {total_comparisons}")

    print("\nComparisons for Custom Heap Sort:")
    for size in sizes:
        total_comparisons = 0
        for _ in range(num_arrays):
            random_array = generate_random_array(size)
            comparisons = custom_heap_sort(random_array)
            total_comparisons += comparisons
        print(f"Input Size: {size}, Total Comparisons: {total_comparisons}")

    print("\nComparisons for Custom Insertion-Merge Sort:")
    for size in sizes:
        total_comparisons = 0
        for _ in range(num_arrays):
            random_array = generate_random_array(size)
            comparisons = ins_mergesort(random_array, size // 2)  # M is set to half of the input size
            total_comparisons += comparisons
        print(f"Input Size: {size}, Total Comparisons: {total_comparisons}")
