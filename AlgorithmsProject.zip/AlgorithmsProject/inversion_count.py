import sys

def count_inversions(filename):
    # Initialize the count of inversions
    inversions = 0
    
    # Open the file and read the array(s)
    with open(filename, 'r') as file:
        _ = int(file.readline())  # Skip the first line
        for line in file:
            arr = list(map(int, line.split()))  # Convert the line to a list of integers
            n = len(arr)
            
            # Iterate over pairs of elements and count inversions
            for i in range(n):
                for j in range(i + 1, n):
                    if arr[i] > arr[j]:
                        inversions += 1
    
    return inversions

if __name__ == "__main__":
    # Check if the correct number of arguments is provided
    if len(sys.argv) != 2:
        print("Usage: python script_name.py filename")
        sys.exit(1)

    # Get the filename from command line arguments
    filename = sys.argv[1]
    
    # Count inversions and print the result
    inversions = count_inversions(filename)
    print("Number of inversions:", inversions)
