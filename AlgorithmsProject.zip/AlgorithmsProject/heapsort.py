import sys

def heapify(arr, n, i):
    # Heapify function to maintain heap property
    largest = i
    l = 2 * i + 1
    r = 2 * i + 2
    
    if l < n and arr[l] > arr[largest]:
        largest = l
    
    if r < n and arr[r] > arr[largest]:
        largest = r
    
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        heapify(arr, n, largest)

def heapsort(arr):
    # Heapsort function
    n = len(arr)

    # Build a max heap
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr, n, i)
    
    comparisons = 0

    # Extract elements one by one
    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]
        comparisons += 1
        heapify(arr, i, 0)
    
    return comparisons

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script_name.py filename")
        sys.exit(1)

    filename = sys.argv[1]
    
    with open(filename, 'r') as file:
        _ = int(file.readline())  
        arr = list(map(int, file.readline().split()))

    comparisons = heapsort(arr)
    print("Sorted array:", arr)
    print("Total comparisons:", comparisons)
